package com.mit.services;

import java.util.Scanner;

public class S1Q1Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S1Q1Server/services/S1Q1Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S1Q1ServerSoapBindingStub stub = new S1Q1ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter two positive numbers");
		int a = sc.nextInt();
		int b = sc.nextInt();
		System.out.println("Add: " + stub.add(a, b));
		System.out.println("Subtract: " + stub.subtract(a, b));
		System.out.println("Multiply: " + stub.mulitply(a, b));
		System.out.println("Divide: " + stub.divide(a, b));
	}
}
