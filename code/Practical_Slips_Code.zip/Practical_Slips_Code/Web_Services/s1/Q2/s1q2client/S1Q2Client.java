package com.mit.services;

import java.util.Scanner;

public class S1Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S1Q2Server/services/S1Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S1Q2ServerSoapBindingStub stub = new S1Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Student Number");
		int sno = sc.nextInt();
		stub.findStudent(sno);
	}
}
