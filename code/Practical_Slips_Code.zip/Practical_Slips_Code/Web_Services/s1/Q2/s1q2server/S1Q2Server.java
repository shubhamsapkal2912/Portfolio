package com.mit.services;

import java.sql.*;

public class S1Q2Server {

	public void findStudent(int sno){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "system";
			String pass = "system";

			con = DriverManager.getConnection(url, user, pass);
			System.out.println("Connected to Database.");

			String sql = "SELECT * FROM student WHERE sno = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, sno);

			rs = pstmt.executeQuery();
			boolean found = false;
			while (rs.next()) {
				found = true;
				System.out.println(
					rs.getInt("sno") + " " + rs.getString("sname") + " " + rs.getString("sclass") + " " + rs.getDouble("sper")
				);
			}
			if(!found) {
				System.out.println("No Student Found");
			}
		} catch (ClassNotFoundException e){
			System.out.println("JDBC not found");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Database Error");
			e.printStackTrace();
		} finally {
			try {if (rs != null) rs.close();} catch (SQLException e) {}
			try {if (pstmt != null) pstmt.close();} catch (SQLException e) {}
			try {if (con != null) con.close();} catch (SQLException e) {}
		}
	}
}
