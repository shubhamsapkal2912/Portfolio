package com.mit.services;

import java.util.Scanner;

public class S5Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S5Q2Server/services/S5Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S5Q2ServerSoapBindingStub stub = new S5Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Course Number");
		int cno = sc.nextInt();
		stub.findCourse(cno);
	}
}
