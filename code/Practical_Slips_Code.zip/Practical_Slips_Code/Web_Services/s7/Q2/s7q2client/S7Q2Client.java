package com.mit.services;

import java.util.Scanner;

public class S7Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S7Q2Server/services/S7Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S7Q2ServerSoapBindingStub stub = new S7Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter username");
		String name = sc.nextLine();
		System.out.println(stub.greet(name));
	}
}
