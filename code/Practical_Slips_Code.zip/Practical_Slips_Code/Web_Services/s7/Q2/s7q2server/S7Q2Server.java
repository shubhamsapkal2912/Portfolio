package com.mit.services;

import java.util.Calendar;

public class S7Q2Server {

	public String greet(String name){
		int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
		String msg;
		if(hour < 12)
			msg = "Good Morning";
		else if(hour < 17)
			msg = "Good Afternoon";
		else if(hour < 21)
			msg = "Good Evening";
		else
			msg = "Good Night";
		return msg + ", " + name;
	}
}
