package com.mit.services;

import java.util.Scanner;

public class S7Q1Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S7Q1Server/services/S7Q1Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S7Q1ServerSoapBindingStub stub = new S7Q1ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter integer number");
		int n = sc.nextInt();
		System.out.println(stub.checkNumber(n));
	}
}
