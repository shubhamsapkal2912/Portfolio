package com.mit.services;

import java.util.Scanner;

public class S4Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S4Q2Server/services/S4Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S4Q2ServerSoapBindingStub stub = new S4Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Employee Number");
		int eno = sc.nextInt();
		stub.findEmployee(eno);
	}
}
