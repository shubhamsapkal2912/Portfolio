package com.mit.services;

import java.util.Scanner;

public class S2Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S2Q2Server/services/S2Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S2Q2ServerSoapBindingStub stub = new S2Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Teacher Number");
		int tno = sc.nextInt();
		stub.findTeacher(tno);
	}
}
