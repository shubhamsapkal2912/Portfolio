package com.mit.services;

public class S2Q1Server {

	public double area(double base, double height){
		return 0.5 * base * height;
	}
}
