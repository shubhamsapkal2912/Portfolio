package com.mit.services;

import java.util.Scanner;

public class S25Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S25Q2Server/services/S25Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S25Q2ServerSoapBindingStub stub = new S25Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter amount in Rupees");
		double amt = sc.nextDouble();
		System.out.println("Enter type of conversion (dollar/pound/euro)");
		String type = sc.next();
		System.out.println("Converted amount: " + stub.convert(amt, type));
	}
}
