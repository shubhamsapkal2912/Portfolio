package com.mit.services;

import java.util.Scanner;

public class S25Q1Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S25Q1Server/services/S25Q1Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S25Q1ServerSoapBindingStub stub = new S25Q1ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter marks of physics, maths, chemistry, biology, marathi, english");
		int p = sc.nextInt();
		int m = sc.nextInt();
		int c = sc.nextInt();
		int b = sc.nextInt();
		int ma = sc.nextInt();
		int e = sc.nextInt();
		System.out.println("Total: " + stub.totalMarks(p, m, c, b, ma, e));
		System.out.println("Percentage: " + stub.percentage(p, m, c, b, ma, e));
	}
}
