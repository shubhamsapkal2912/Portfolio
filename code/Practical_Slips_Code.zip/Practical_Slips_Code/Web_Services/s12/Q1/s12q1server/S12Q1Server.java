package com.mit.services;

public class S12Q1Server {

	public int totalMarks(int m1, int m2, int m3){
		return m1 + m2 + m3;
	}

	public double average(int m1, int m2, int m3){
		return totalMarks(m1, m2, m3) / 3.0;
	}

	public String classObtained(int m1, int m2, int m3){
		double avg = average(m1, m2, m3);
		if(avg >= 70)
			return "Distinction";
		else if(avg >= 60)
			return "First Class";
		else if(avg >= 50)
			return "Second Class";
		else if(avg >= 40)
			return "Pass Class";
		else
			return "Fail";
	}
}
