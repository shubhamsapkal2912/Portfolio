package com.mit.services;

import java.util.Scanner;

public class S12Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S12Q2Server/services/S12Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S12Q2ServerSoapBindingStub stub = new S12Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter x and y");
		double x = sc.nextDouble();
		double y = sc.nextDouble();
		System.out.println("x^y = " + stub.power(x, y));
	}
}
