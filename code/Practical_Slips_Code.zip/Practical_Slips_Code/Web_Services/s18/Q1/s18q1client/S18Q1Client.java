package com.mit.services;

import java.util.Scanner;

public class S18Q1Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S18Q1Server/services/S18Q1Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S18Q1ServerSoapBindingStub stub = new S18Q1ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter radius");
		double r = sc.nextDouble();
		System.out.println("Area: " + stub.area(r));
		System.out.println("Volume: " + stub.volume(r));
	}
}
