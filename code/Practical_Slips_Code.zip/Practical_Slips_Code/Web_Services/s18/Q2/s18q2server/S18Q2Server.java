package com.mit.services;

public class S18Q2Server {

	public String checkArmstrong(int n){
		int temp = n, sum = 0;
		int digits = String.valueOf(n).length();
		while(temp > 0){
			sum += (int) Math.pow(temp % 10, digits);
			temp = temp / 10;
		}
		if(sum == n)
			return n + " is an Armstrong number";
		else
			return n + " is not an Armstrong number";
	}
}
