package com.mit.services;

public class S14Q2Server {

	public long factorial(int n){
		long fact = 1;
		for(int i = 2; i <= n; i++){
			fact = fact * i;
		}
		return fact;
	}
}
