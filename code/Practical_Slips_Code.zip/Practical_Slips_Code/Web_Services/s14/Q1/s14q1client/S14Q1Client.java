package com.mit.services;

import java.util.Scanner;

public class S14Q1Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S14Q1Server/services/S14Q1Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S14Q1ServerSoapBindingStub stub = new S14Q1ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter base and height");
		double b = sc.nextDouble();
		double h = sc.nextDouble();
		System.out.println("Area of triangle: " + stub.area(b, h));
	}
}
