package com.mit.services;

public class S21Q1Server {

	public String profitOrLoss(double costPrice, double sellingPrice){
		if(sellingPrice > costPrice)
			return "Profit of " + (sellingPrice - costPrice);
		else if(sellingPrice < costPrice)
			return "Loss of " + (costPrice - sellingPrice);
		else
			return "No profit no loss";
	}
}
