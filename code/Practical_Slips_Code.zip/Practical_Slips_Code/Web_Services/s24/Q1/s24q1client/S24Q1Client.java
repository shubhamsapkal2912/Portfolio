package com.mit.services;

import java.util.Scanner;

public class S24Q1Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S24Q1Server/services/S24Q1Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S24Q1ServerSoapBindingStub stub = new S24Q1ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter marks of three subjects");
		int m1 = sc.nextInt();
		int m2 = sc.nextInt();
		int m3 = sc.nextInt();
		System.out.println("Total: " + stub.totalMarks(m1, m2, m3));
		System.out.println("Average: " + stub.average(m1, m2, m3));
		System.out.println("Class: " + stub.classObtained(m1, m2, m3));
	}
}
