package com.mit.services;

import java.util.Scanner;

public class S24Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S24Q2Server/services/S24Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S24Q2ServerSoapBindingStub stub = new S24Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Student Number");
		int sno = sc.nextInt();
		stub.findStudent(sno);
	}
}
