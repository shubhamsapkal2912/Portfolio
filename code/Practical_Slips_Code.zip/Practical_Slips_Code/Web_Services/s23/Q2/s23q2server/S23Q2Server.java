package com.mit.services;

public class S23Q2Server {

	public int reverse(int n){
		int rev = 0;
		while(n > 0){
			rev = rev * 10 + n % 10;
			n = n / 10;
		}
		return rev;
	}
}
