package com.mit.services;

import java.util.Scanner;

public class S23Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S23Q2Server/services/S23Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S23Q2ServerSoapBindingStub stub = new S23Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter positive integer number");
		int n = sc.nextInt();
		System.out.println("Reverse: " + stub.reverse(n));
	}
}
