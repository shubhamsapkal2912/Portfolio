package com.mit.services;

public class S17Q1Server {

	public int totalMarks(int physics, int maths, int chemistry, int biology, int marathi, int english){
		return physics + maths + chemistry + biology + marathi + english;
	}

	public double percentage(int physics, int maths, int chemistry, int biology, int marathi, int english){
		return totalMarks(physics, maths, chemistry, biology, marathi, english) / 6.0;
	}
}
