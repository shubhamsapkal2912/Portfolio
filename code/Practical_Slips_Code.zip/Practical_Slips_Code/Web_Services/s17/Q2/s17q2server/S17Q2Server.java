package com.mit.services;

public class S17Q2Server {

	public String checkPalindrome(int n){
		int temp = n, rev = 0;
		while(temp > 0){
			rev = rev * 10 + temp % 10;
			temp = temp / 10;
		}
		if(rev == n)
			return n + " is a Palindrome";
		else
			return n + " is not a Palindrome";
	}
}
