package com.mit.services;

import java.util.Scanner;

public class S17Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S17Q2Server/services/S17Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S17Q2ServerSoapBindingStub stub = new S17Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter positive integer number");
		int n = sc.nextInt();
		System.out.println(stub.checkPalindrome(n));
	}
}
