package com.mit.services;

import java.util.Scanner;

public class S16Q1Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S16Q1Server/services/S16Q1Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S16Q1ServerSoapBindingStub stub = new S16Q1ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter x1 y1 x2 y2");
		double x1 = sc.nextDouble();
		double y1 = sc.nextDouble();
		double x2 = sc.nextDouble();
		double y2 = sc.nextDouble();
		System.out.println("Distance: " + stub.distance(x1, y1, x2, y2));
	}
}
