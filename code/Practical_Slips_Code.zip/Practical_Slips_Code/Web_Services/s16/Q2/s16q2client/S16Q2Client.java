package com.mit.services;

import java.util.Scanner;

public class S16Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S16Q2Server/services/S16Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S16Q2ServerSoapBindingStub stub = new S16Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter string");
		String str = sc.nextLine();
		System.out.println("Number of vowels: " + stub.countVowels(str));
	}
}
