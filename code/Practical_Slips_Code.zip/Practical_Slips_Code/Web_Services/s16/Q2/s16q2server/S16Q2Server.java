package com.mit.services;

public class S16Q2Server {

	public int countVowels(String str){
		int count = 0;
		for(int i = 0; i < str.length(); i++){
			char c = Character.toLowerCase(str.charAt(i));
			if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
				count++;
		}
		return count;
	}
}
