package com.mit.services;

import java.util.Scanner;

public class S9Q1Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S9Q1Server/services/S9Q1Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S9Q1ServerSoapBindingStub stub = new S9Q1ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter cost price and selling price");
		double cp = sc.nextDouble();
		double sp = sc.nextDouble();
		System.out.println(stub.profitOrLoss(cp, sp));
	}
}
