package com.mit.services;

import java.util.Scanner;

public class S9Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S9Q2Server/services/S9Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S9Q2ServerSoapBindingStub stub = new S9Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter email id");
		String email = sc.nextLine();
		System.out.println(stub.validateEmail(email));
	}
}
