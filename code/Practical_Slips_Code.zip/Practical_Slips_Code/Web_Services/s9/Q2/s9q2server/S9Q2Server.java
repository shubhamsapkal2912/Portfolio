package com.mit.services;

import java.util.regex.Pattern;

public class S9Q2Server {

	public String validateEmail(String email){
		String regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
		if(Pattern.matches(regex, email))
			return "Valid email id";
		else
			return "Invalid email id";
	}
}
