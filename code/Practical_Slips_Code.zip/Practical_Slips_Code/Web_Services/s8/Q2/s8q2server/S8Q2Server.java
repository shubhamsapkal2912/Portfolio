package com.mit.services;

public class S8Q2Server {

	public double celsiusToFahrenheit(double c){
		return (c * 9 / 5) + 32;
	}
}
