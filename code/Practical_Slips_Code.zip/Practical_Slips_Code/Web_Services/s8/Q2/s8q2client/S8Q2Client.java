package com.mit.services;

import java.util.Scanner;

public class S8Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S8Q2Server/services/S8Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S8Q2ServerSoapBindingStub stub = new S8Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Celsius");
		double c = sc.nextDouble();
		System.out.println("Fahrenheit: " + stub.celsiusToFahrenheit(c));
	}
}
