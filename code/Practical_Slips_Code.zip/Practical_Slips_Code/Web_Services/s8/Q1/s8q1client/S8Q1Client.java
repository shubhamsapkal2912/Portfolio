package com.mit.services;

import java.util.Scanner;

public class S8Q1Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S8Q1Server/services/S8Q1Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S8Q1ServerSoapBindingStub stub = new S8Q1ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter year");
		int year = sc.nextInt();
		System.out.println(stub.checkLeap(year));
	}
}
