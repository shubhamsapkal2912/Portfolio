package com.mit.services;

public class S8Q1Server {

	public String checkLeap(int year){
		if((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
			return year + " is a Leap year";
		else
			return year + " is not a Leap year";
	}
}
