package com.mit.services;

import java.util.Scanner;

public class S11Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S11Q2Server/services/S11Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S11Q2ServerSoapBindingStub stub = new S11Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter mobile no");
		String mobile = sc.next();
		System.out.println(stub.validateMobile(mobile));
	}
}
