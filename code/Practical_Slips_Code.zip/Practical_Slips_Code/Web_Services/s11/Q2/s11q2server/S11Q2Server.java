package com.mit.services;

import java.util.regex.Pattern;

public class S11Q2Server {

	public String validateMobile(String mobile){
		if(Pattern.matches("[0-9]{10}", mobile))
			return "Valid mobile no";
		else
			return "Invalid mobile no";
	}
}
