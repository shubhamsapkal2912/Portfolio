package com.mit.services;

import java.util.Scanner;

public class S11Q1Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S11Q1Server/services/S11Q1Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S11Q1ServerSoapBindingStub stub = new S11Q1ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter single character");
		String ch = sc.next();
		System.out.println(stub.checkCharacter(ch));
	}
}
