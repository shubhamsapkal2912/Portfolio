package com.mit.services;

public class S11Q1Server {

	public String checkCharacter(String ch){
		char c = Character.toLowerCase(ch.charAt(0));
		if(!Character.isLetter(c))
			return "Not an alphabet";
		if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
			return "VOWEL";
		else
			return "CONSONANT";
	}
}
