package com.mit.services;

import java.util.Scanner;

public class S6Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S6Q2Server/services/S6Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S6Q2ServerSoapBindingStub stub = new S6Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Book Number");
		int bno = sc.nextInt();
		stub.findBook(bno);
	}
}
