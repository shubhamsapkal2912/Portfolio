package com.mit.services;

import java.util.Scanner;

public class S6Q1Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S6Q1Server/services/S6Q1Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S6Q1ServerSoapBindingStub stub = new S6Q1ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter radius");
		double r = sc.nextDouble();
		System.out.println("Area: " + stub.area(r));
		System.out.println("Volume: " + stub.volume(r));
	}
}
