package com.mit.services;

public class S6Q1Server {

	public double area(double radius){
		return Math.PI * radius * radius;
	}

	// volume of sphere having same radius
	public double volume(double radius){
		return (4.0 / 3.0) * Math.PI * radius * radius * radius;
	}
}
