package com.mit.services;

import java.util.Scanner;

public class S3Q1Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S3Q1Server/services/S3Q1Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S3Q1ServerSoapBindingStub stub = new S3Q1ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter length, breadth and height");
		double l = sc.nextDouble();
		double b = sc.nextDouble();
		double h = sc.nextDouble();
		System.out.println("Surface area: " + stub.surfaceArea(l, b, h));
		System.out.println("Volume: " + stub.volume(l, b, h));
	}
}
