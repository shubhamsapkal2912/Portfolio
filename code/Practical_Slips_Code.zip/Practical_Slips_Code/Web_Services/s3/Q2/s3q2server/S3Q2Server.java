package com.mit.services;

import java.sql.*;

public class S3Q2Server {

	public void findActor(int ano){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "system";
			String pass = "system";

			con = DriverManager.getConnection(url, user, pass);
			System.out.println("Connected to Database.");

			String sql = "SELECT * FROM actor WHERE ano = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, ano);

			rs = pstmt.executeQuery();
			boolean found = false;
			while (rs.next()) {
				found = true;
				System.out.println(
					rs.getInt("ano") + " " + rs.getString("aname") + " " + rs.getString("amovie")
				);
			}
			if(!found) {
				System.out.println("No Actor Found");
			}
		} catch (ClassNotFoundException e){
			System.out.println("JDBC not found");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Database Error");
			e.printStackTrace();
		} finally {
			try {if (rs != null) rs.close();} catch (SQLException e) {}
			try {if (pstmt != null) pstmt.close();} catch (SQLException e) {}
			try {if (con != null) con.close();} catch (SQLException e) {}
		}
	}
}
