package com.mit.services;

import java.util.Scanner;

public class S3Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S3Q2Server/services/S3Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S3Q2ServerSoapBindingStub stub = new S3Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Actor Number");
		int ano = sc.nextInt();
		stub.findActor(ano);
	}
}
