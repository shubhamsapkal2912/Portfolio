package com.mit.services;

public class S15Q1Server {

	public double surfaceArea(double l, double b, double h){
		return 2 * (l * b + l * h + b * h);
	}

	public double volume(double l, double b, double h){
		return l * b * h;
	}
}
