package com.mit.services;

public class S13Q2Server {

	public String checkPerfect(int n){
		int sum = 0;
		for(int i = 1; i <= n / 2; i++){
			if(n % i == 0)
				sum += i;
		}
		if(n > 0 && sum == n)
			return n + " is a Perfect number";
		else
			return n + " is not a Perfect number";
	}
}
