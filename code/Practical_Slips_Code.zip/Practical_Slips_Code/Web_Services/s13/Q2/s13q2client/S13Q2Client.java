package com.mit.services;

import java.util.Scanner;

public class S13Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S13Q2Server/services/S13Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S13Q2ServerSoapBindingStub stub = new S13Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter positive integer number");
		int n = sc.nextInt();
		System.out.println(stub.checkPerfect(n));
	}
}
