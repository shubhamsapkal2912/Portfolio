package com.mit.services;

public class S13Q1Server {

	public int add(int a, int b){
		return a + b;
	}

	public int subtract(int a, int b){
		return a - b;
	}

	public int mulitply(int a, int b){
		return a * b;
	}

	public int divide(int a, int b){
		return a / b;
	}
}
