package com.mit.services;

import java.util.Scanner;

public class S20Q1Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S20Q1Server/services/S20Q1Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S20Q1ServerSoapBindingStub stub = new S20Q1ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter year");
		int year = sc.nextInt();
		System.out.println(stub.checkLeap(year));
	}
}
