package com.mit.services;

import java.util.Scanner;

public class S20Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S20Q2Server/services/S20Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S20Q2ServerSoapBindingStub stub = new S20Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter x and y");
		double x = sc.nextDouble();
		double y = sc.nextDouble();
		System.out.println("x^y = " + stub.power(x, y));
	}
}
