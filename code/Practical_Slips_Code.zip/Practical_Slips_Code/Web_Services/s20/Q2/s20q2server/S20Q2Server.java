package com.mit.services;

public class S20Q2Server {

	public double power(double x, double y){
		return Math.pow(x, y);
	}
}
