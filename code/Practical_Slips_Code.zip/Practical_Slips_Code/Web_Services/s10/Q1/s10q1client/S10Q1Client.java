package com.mit.services;

import java.util.Scanner;

public class S10Q1Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S10Q1Server/services/S10Q1Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S10Q1ServerSoapBindingStub stub = new S10Q1ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter single digit number");
		int n = sc.nextInt();
		System.out.println(stub.numberToWords(n));
	}
}
