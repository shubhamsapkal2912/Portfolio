package com.mit.services;

import java.util.Scanner;

public class S10Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S10Q2Server/services/S10Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S10Q2ServerSoapBindingStub stub = new S10Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter amount in Rupees");
		double amt = sc.nextDouble();
		System.out.println("Enter type of conversion (dollar/pound/euro)");
		String type = sc.next();
		System.out.println("Converted amount: " + stub.convert(amt, type));
	}
}
