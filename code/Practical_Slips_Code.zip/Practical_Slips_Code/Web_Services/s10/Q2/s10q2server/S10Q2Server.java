package com.mit.services;

public class S10Q2Server {

	public double convert(double rupees, String type){
		if(type.equalsIgnoreCase("dollar"))
			return rupees / 83.0;
		else if(type.equalsIgnoreCase("pound"))
			return rupees / 105.0;
		else if(type.equalsIgnoreCase("euro"))
			return rupees / 90.0;
		else
			return -1;
	}
}
