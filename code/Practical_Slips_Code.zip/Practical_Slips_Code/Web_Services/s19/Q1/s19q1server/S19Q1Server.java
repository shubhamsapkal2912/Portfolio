package com.mit.services;

public class S19Q1Server {

	public String checkNumber(int n){
		if(n > 0)
			return "Positive";
		else if(n < 0)
			return "Negative";
		else
			return "Zero";
	}
}
