package com.mit.services;

import java.util.Scanner;

public class S19Q1Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S19Q1Server/services/S19Q1Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S19Q1ServerSoapBindingStub stub = new S19Q1ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter integer number");
		int n = sc.nextInt();
		System.out.println(stub.checkNumber(n));
	}
}
