package com.mit.services;

public class S19Q2Server {

	public String convert(int n, String type){
		if(type.equalsIgnoreCase("binary"))
			return Integer.toBinaryString(n);
		else if(type.equalsIgnoreCase("octal"))
			return Integer.toOctalString(n);
		else if(type.equalsIgnoreCase("hexadecimal"))
			return Integer.toHexString(n).toUpperCase();
		else
			return "Invalid type";
	}
}
