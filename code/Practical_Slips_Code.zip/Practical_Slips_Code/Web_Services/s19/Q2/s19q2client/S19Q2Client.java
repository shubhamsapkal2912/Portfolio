package com.mit.services;

import java.util.Scanner;

public class S19Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S19Q2Server/services/S19Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S19Q2ServerSoapBindingStub stub = new S19Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter decimal number");
		int n = sc.nextInt();
		System.out.println("Enter type of conversion (binary/octal/hexadecimal)");
		String type = sc.next();
		System.out.println("Result: " + stub.convert(n, type));
	}
}
