package com.mit.services;

public class S22Q1Server {

	public String numberToWords(int n){
		String[] words = {"Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"};
		if(n < 0 || n > 9)
			return "Enter single digit number";
		return words[n];
	}
}
