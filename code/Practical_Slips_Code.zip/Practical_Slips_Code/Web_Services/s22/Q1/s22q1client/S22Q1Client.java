package com.mit.services;

import java.util.Scanner;

public class S22Q1Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S22Q1Server/services/S22Q1Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S22Q1ServerSoapBindingStub stub = new S22Q1ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter single digit number");
		int n = sc.nextInt();
		System.out.println(stub.numberToWords(n));
	}
}
