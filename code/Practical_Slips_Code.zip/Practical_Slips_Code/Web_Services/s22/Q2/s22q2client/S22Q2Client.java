package com.mit.services;

import java.util.Scanner;

public class S22Q2Client {
	public static void main(String args[]) throws Exception{
		java.net.URL endpointUrl = new java.net.URL("http://localhost:8080/S22Q2Server/services/S22Q2Server");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		S22Q2ServerSoapBindingStub stub = new S22Q2ServerSoapBindingStub(endpointUrl, service);
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter positive integer number");
		int n = sc.nextInt();
		System.out.println("Factorial: " + stub.factorial(n));
	}
}
