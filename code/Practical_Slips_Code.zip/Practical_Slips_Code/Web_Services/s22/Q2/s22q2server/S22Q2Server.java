package com.mit.services;

public class S22Q2Server {

	public long factorial(int n){
		long fact = 1;
		for(int i = 2; i <= n; i++){
			fact = fact * i;
		}
		return fact;
	}
}
