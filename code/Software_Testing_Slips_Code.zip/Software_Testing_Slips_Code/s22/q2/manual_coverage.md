# Manual Statement & Function Coverage + Control Flow Graph  (Slip 22 Q2)

## Program
```python
def sum_positive(nums):          # 1
    total = 0                    # 2
    for n in nums:               # 3
        if n > 0:                # 4
            total += n           # 5
    return total                 # 6


def classify(total):             # 7
    if total > 10:               # 8
        return "HIGH"            # 9
    return "LOW"                 # 10
```

## Test used
`sum_positive([4, -1, 9])` -> 13   (only this one test is run)

## 1. Statement coverage (manual)
Count executable statements inside the functions (line numbers of the comments above; `def` lines excluded).

| Stmt | Code | Executed? |
|---|---|---|
| 2 | `total = 0` | Yes |
| 3 | `for n in nums` | Yes |
| 4 | `if n > 0` | Yes |
| 5 | `total += n` | Yes (4 and 9 are positive) |
| 6 | `return total` | Yes |
| 8 | `if total > 10` | **No** (classify never called) |
| 9 | `return "HIGH"` | **No** |
| 10 | `return "LOW"` | **No** |

Statement coverage = executed / total x 100 = **5 / 8 x 100 = 62.5 %**

## 2. Function coverage (manual)
| Function | Called? |
|---|---|
| `sum_positive` | Yes |
| `classify` | **No** |

Function coverage = 1 / 2 x 100 = **50 %**

## 3. Control Flow Graph  (`cfg_sum_positive.png`)
Nodes: START, 1 (`total=0`), 2 (`for`), 3 (`if n>0`), 4 (`total+=n`), 5 (`return`), END -> **N = 7**
Edges: S-1, 1-2, 2-3, 3-4 (T), 4-2, 3-2 (F), 2-5, 5-END -> **E = 8**
Cyclomatic complexity = E - N + 2 = 8 - 7 + 2 = **3** (= 2 decisions + 1)

Independent paths:
1. START-1-2-5-END (empty list)
2. START-1-2-3-4-2-5-END (positive item)
3. START-1-2-3-2-5-END (non-positive item)

## 4. Tool cross-check (coverage.py)
```
Name        Stmts   Miss Branch BrPart  Cover   Missing
-------------------------------------------------------
sample.py      10      3      6      0    69%   10-12
-------------------------------------------------------
TOTAL          10      3      6      0    69%
```
coverage.py counts the `def` lines (executed at import) as statements: 7 of 10 = 70 % statement coverage;
its 69 % figure also includes branch coverage (`--branch`). The manual method above (body statements only) gives 62.5 %.
Both agree that `classify` (lines 10-12 in the file) is never executed.
To reach 100 %: add `classify(5)` and `classify(50)` tests.
