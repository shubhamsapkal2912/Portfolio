def sum_positive(nums):          # 1
    total = 0                    # 2
    for n in nums:               # 3
        if n > 0:                # 4
            total += n           # 5
    return total                 # 6


def classify(total):             # 7
    if total > 10:               # 8
        return "HIGH"            # 9
    return "LOW"                 # 10
