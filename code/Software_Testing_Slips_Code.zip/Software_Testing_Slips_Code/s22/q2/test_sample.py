from sample import sum_positive

def test_sum_positive():
    assert sum_positive([4, -1, 9]) == 13
