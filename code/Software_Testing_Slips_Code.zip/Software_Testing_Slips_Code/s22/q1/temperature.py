def to_fahrenheit(c):
    return c * 9 / 5 + 32


def to_celsius(f):
    return (f - 32) * 5 / 9


def describe(c):
    if c < 0:
        return "Freezing"
    elif c < 15:
        return "Cold"
    elif c < 30:
        return "Warm"
    return "Hot"


def average(readings):
    if not readings:
        return None
    total = 0
    for r in readings:
        total += r
    return total / len(readings)
