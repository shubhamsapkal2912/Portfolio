from temperature import to_fahrenheit, to_celsius, describe, average

def test_to_fahrenheit():
    assert to_fahrenheit(100) == 212

def test_to_celsius():
    assert to_celsius(212) == 100

def test_describe_all_ranges():
    assert describe(-5) == "Freezing"
    assert describe(10) == "Cold"
    assert describe(20) == "Warm"
    assert describe(35) == "Hot"

def test_average():
    assert average([10, 20, 30]) == 20
    assert average([]) is None
