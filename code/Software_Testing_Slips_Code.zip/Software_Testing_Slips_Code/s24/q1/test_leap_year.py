from leap_year import is_leap, check_years

def test_div_400():
    assert is_leap(2000)

def test_div_100_not_400():
    assert not is_leap(1900)

def test_div_4():
    assert is_leap(2024)

def test_normal():
    assert not is_leap(2023)

def test_check_years():
    assert check_years([1900, 2000, 2024]) == [2000, 2024]
