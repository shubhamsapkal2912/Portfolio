def is_leap(year):
    if year % 400 == 0:
        return True
    elif year % 100 == 0:
        return False
    elif year % 4 == 0:
        return True
    else:
        return False


def check_years(years):
    leaps = []
    for y in years:
        if is_leap(y):
            leaps.append(y)
    return leaps


if __name__ == "__main__":
    years = [1900, 2000, 2023, 2024, 2100]
    for y in years:
        print(y, "-> Leap year" if is_leap(y) else "-> Not a leap year")
    print("Leap years found:", check_years(years))
