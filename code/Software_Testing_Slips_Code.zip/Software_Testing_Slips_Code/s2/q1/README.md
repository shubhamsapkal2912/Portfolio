# Defect identification - Course Feedback Form

1. Open `feedback_form.html` in a browser.
2. Test each field with invalid / empty / boundary data (see defect list).
3. Defects are recorded in `feedback_form_defects.xlsx`.
4. Types: **UI** = look/layout/usability, **Functional** = feature does not work,
   **Validation** = wrong input is accepted or valid input rejected.
