def shipping_cost(weight, distance, is_member):
    if weight <= 0 or distance <= 0:          # decision 1 (compound: 2 conditions)
        return -1
    cost = 50
    if weight > 10:                           # decision 2
        cost += (weight - 10) * 5
    if distance > 500 and weight > 5:         # decision 3 (compound: 2 conditions)
        cost += 100
    elif distance > 100:                      # decision 4
        cost += 40
    if is_member:                             # decision 5
        cost *= 0.9
    return round(cost, 2)
