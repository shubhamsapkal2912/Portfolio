# Coverage Report - `shipping.py`  (Slip 7 Q1)

## Tool used
`coverage.py` with branch measurement + pytest.

```
pip install coverage pytest
coverage run --branch -m pytest
coverage report -m
coverage html          # opens htmlcov/index.html
```

## Source under test
```python
def shipping_cost(weight, distance, is_member):
    if weight <= 0 or distance <= 0:          # decision 1 (compound: 2 conditions)
        return -1
    cost = 50
    if weight > 10:                           # decision 2
        cost += (weight - 10) * 5
    if distance > 500 and weight > 5:         # decision 3 (compound: 2 conditions)
        cost += 100
    elif distance > 100:                      # decision 4
        cost += 40
    if is_member:                             # decision 5
        cost *= 0.9
    return round(cost, 2)
```

## Tests executed
```python
from shipping import shipping_cost

def test_light_near_non_member():
    assert shipping_cost(5, 50, False) == 50

def test_invalid_weight():
    assert shipping_cost(0, 100, False) == -1

def test_heavy_far_member():
    assert shipping_cost(12, 600, True) == 144.0
```

## Report (`coverage report -m`)
```
Name          Stmts   Miss Branch BrPart  Cover   Missing
---------------------------------------------------------
shipping.py      13      1     10      1    91%   10
---------------------------------------------------------
TOTAL            13      1     10      1    91%
```

## Interpretation
* Statements : 13, executed 12, missed 1  -> **statement coverage 92%**
* Branches   : 10 total, 9 covered, 1 missed -> **branch (decision) coverage 90%**
* Combined (statement+branch) figure printed by the tool: **91%**
* **Missed lines (code blocks never executed):** [10]
* **Missed branches (from line -> to line):** [[9, 10]]

### Condition coverage (analysed manually - coverage.py does not report it)
| Decision | Condition | Tests where True | Tests where False | Condition covered? |
|---|---|---|---|---|
| D1 `weight<=0 or distance<=0` | `weight <= 0` | test_invalid_weight | other 2 tests | Yes (T and F) |
| | `distance <= 0` | never | all 3 tests (short-circuit: only evaluated when weight>0) | **No - never True** |
| D3 `distance>500 and weight>5` | `distance > 500` | test_heavy_far_member | test_light_near_non_member | Yes |
| | `weight > 5` | test_heavy_far_member | never evaluated False (only reached when distance>500) | **No - never False** |
| D4 `distance > 100` | - | never True (elif never reached with distance in 101..500) | test_light_near | **No - True branch missed** |


### Path coverage
Path coverage needs every combination of decisions to be exercised. With several independent
decisions the number of paths is large (2^n), but the 3 tests only drive 3 of them, so path
coverage is **low**; branch coverage is the practical target.

## Missed code blocks and what test would cover them
Open `htmlcov/index.html` -> click `shipping.py`; red lines are the missed lines listed above.
Add tests that drive the missed branches (see Slip 8/18/20/22 for the improvement technique).
