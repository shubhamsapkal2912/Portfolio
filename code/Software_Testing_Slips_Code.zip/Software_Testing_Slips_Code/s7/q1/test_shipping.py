from shipping import shipping_cost

def test_light_near_non_member():
    assert shipping_cost(5, 50, False) == 50

def test_invalid_weight():
    assert shipping_cost(0, 100, False) == -1

def test_heavy_far_member():
    assert shipping_cost(12, 600, True) == 144.0
