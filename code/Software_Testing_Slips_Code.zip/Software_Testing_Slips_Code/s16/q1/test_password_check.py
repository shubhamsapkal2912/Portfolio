from password_check import password_strength

def test_short_password():
    assert password_strength("abc") == "Weak"

def test_strong_password():
    assert password_strength("Ronit@123") == "Strong"

def test_medium_password():
    assert password_strength("ronit1234") == "Medium"
