def password_strength(pw):
    if len(pw) < 8:                           # decision 1
        return "Weak"
    has_upper = has_digit = has_special = False
    for ch in pw:                             # loop decision
        if ch.isupper():                      # decision 2
            has_upper = True
        elif ch.isdigit():                    # decision 3
            has_digit = True
        elif not ch.isalnum():                # decision 4
            has_special = True
    score = has_upper + has_digit + has_special
    if score == 3 and len(pw) >= 12:          # decision 5 (compound)
        return "Very Strong"
    elif score == 3:                          # decision 6
        return "Strong"
    elif score >= 1:                          # decision 7
        return "Medium"
    return "Weak"
