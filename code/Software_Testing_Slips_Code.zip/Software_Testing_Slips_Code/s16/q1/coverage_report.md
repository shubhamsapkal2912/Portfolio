# Coverage Report - `password_check.py`  (Slip 16 Q1)

## Tool used
`coverage.py` with branch measurement + pytest.

```
pip install coverage pytest
coverage run --branch -m pytest
coverage report -m
coverage html          # opens htmlcov/index.html
```

## Source under test
```python
def password_strength(pw):
    if len(pw) < 8:                           # decision 1
        return "Weak"
    has_upper = has_digit = has_special = False
    for ch in pw:                             # loop decision
        if ch.isupper():                      # decision 2
            has_upper = True
        elif ch.isdigit():                    # decision 3
            has_digit = True
        elif not ch.isalnum():                # decision 4
            has_special = True
    score = has_upper + has_digit + has_special
    if score == 3 and len(pw) >= 12:          # decision 5 (compound)
        return "Very Strong"
    elif score == 3:                          # decision 6
        return "Strong"
    elif score >= 1:                          # decision 7
        return "Medium"
    return "Weak"
```

## Tests executed
```python
from password_check import password_strength

def test_short_password():
    assert password_strength("abc") == "Weak"

def test_strong_password():
    assert password_strength("Ronit@123") == "Strong"

def test_medium_password():
    assert password_strength("ronit1234") == "Medium"
```

## Report (`coverage report -m`)
```
Name                Stmts   Miss Branch BrPart  Cover   Missing
---------------------------------------------------------------
password_check.py      19      2     16      2    89%   14, 19
---------------------------------------------------------------
TOTAL                  19      2     16      2    89%
```

## Interpretation
* Statements : 19, executed 17, missed 2  -> **statement coverage 89%**
* Branches   : 16 total, 14 covered, 2 missed -> **branch (decision) coverage 88%**
* Combined (statement+branch) figure printed by the tool: **89%**
* **Missed lines (code blocks never executed):** [14, 19]
* **Missed branches (from line -> to line):** [[13, 14], [17, 19]]

### Condition coverage (analysed manually - coverage.py does not report it)
| Decision | Condition | Tests where True | Tests where False | Condition covered? |
|---|---|---|---|---|
| D1 `len(pw) < 8` | - | test_short_password | test_strong, test_medium | Yes |
| D5 `score == 3 and len(pw) >= 12` | `score == 3` | test_strong_password | test_medium_password | Yes |
| | `len(pw) >= 12` | never (only evaluated when score==3, and that password has 9 chars) | test_strong_password | **No - never True** |
| D2 `ch.isupper()` | - | test_strong | test_medium | Yes |
| D3/D4 `ch.isdigit()` / `not ch.isalnum()` | - | test_strong, test_medium | test_strong (letters) | Yes |
| D7 `score >= 1` (False path -> final `return "Weak"`, line 19) | - | test_medium | never False | **No - last return missed** |


### Path coverage
Path coverage needs every combination of decisions to be exercised. With several independent
decisions the number of paths is large (2^n), but the 3 tests only drive 3 of them, so path
coverage is **low**; branch coverage is the practical target.

## Missed code blocks and what test would cover them
Open `htmlcov/index.html` -> click `password_check.py`; red lines are the missed lines listed above.
Add tests that drive the missed branches (see Slip 8/18/20/22 for the improvement technique).
