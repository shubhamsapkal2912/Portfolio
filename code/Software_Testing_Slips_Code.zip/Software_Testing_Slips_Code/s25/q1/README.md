# Scholarship Application form - defect report
* Form under test: `scholarship_application.html` (open in browser).
* Report: `scholarship_application_defect_report.xlsx`
* **Severity** = technical impact of the defect (Critical/Major/Minor/Trivial).
* **Priority** = how soon it should be fixed (P1 highest ... P4 lowest), decided with business input.
