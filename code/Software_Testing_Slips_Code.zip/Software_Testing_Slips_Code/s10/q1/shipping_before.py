def shipping_charge_before(country, weight, express, insured, member):
    """High complexity: long if/elif chains + nested conditions."""
    charge = 0
    if country == "IN":
        if weight <= 1:
            charge = 40
        elif weight <= 5:
            charge = 90
        elif weight <= 10:
            charge = 160
        else:
            charge = 250
    elif country == "US":
        if weight <= 1:
            charge = 800
        elif weight <= 5:
            charge = 1500
        else:
            charge = 2500
    elif country == "UK":
        if weight <= 1:
            charge = 700
        elif weight <= 5:
            charge = 1300
        else:
            charge = 2200
    else:
        charge = -1
    if charge == -1:
        return -1
    if express:
        charge = charge * 2
    if insured:
        charge = charge + 50
    if member:
        charge = charge * 0.9
    return round(charge, 2)
