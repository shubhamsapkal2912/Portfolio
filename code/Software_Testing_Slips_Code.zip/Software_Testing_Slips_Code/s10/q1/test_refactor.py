import itertools
from shipping_before import shipping_charge_before as old
from shipping_after import shipping_charge_after as new


def test_refactor_preserves_behaviour():
    for c, w, e, i, m in itertools.product(["IN", "US", "UK", "XX"], [0.5, 1, 3, 5, 7, 10, 20],
                                           [True, False], [True, False], [True, False]):
        assert old(c, w, e, i, m) == new(c, w, e, i, m)
