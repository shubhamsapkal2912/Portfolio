# Refactor a Program with High Cyclomatic Complexity  (Slip 10 Q1)

## 1. Original (`shipping_before.py`)  - V(G) = **15**
Decisions: country checks (3) + weight slabs (3 + 2 + 2) + `charge == -1` (1) + `express`, `insured`, `member` (3) = 14 -> V(G) = 14 + 1.
Radon / manual result: **V(G) = 15** -> *Complex*, hard to test (needs 15 tests for just branch coverage).

## 2. Refactoring applied (`shipping_after.py`)
* **Replace conditional with data** - nested country/weight ladders moved into the `RATES` table.
* **Extract function** - `_base_charge()` loops over slabs.
* **Ternary modifiers** for express / insured / member.
* Behaviour unchanged (see equivalence test).

## 3. Recomputed complexity
```
shipping_before.py
    F 1:0 shipping_charge_before - C (15)
shipping_after.py
    F 15:0 shipping_charge_after - A (5)
    F 9:0 _base_charge - A (3)
```

| Unit | Before | After |
|---|---|---|
| shipping_charge | **15** | **5** |
| _base_charge | - | **3** |
| Highest single unit | 15 | 5 |

## 4. Effect on testability
* Minimum tests for branch coverage fell from **15** (one giant function) to **5** + **3**.
* Slab boundaries are tested through data (`RATES`) rather than separate code paths; adding a country needs a table row + one test row, not new branches.
* `_base_charge` can be unit-tested alone (isolation) - easier to locate failures.
* Lower complexity = fewer paths = higher achievable path/branch coverage with fewer tests.
* Equivalence test guarantees the refactor is safe (regression test).

```
.                                                                        [100%]
1 passed in 0.01s
```
