# slabs: (max_weight, charge) - last slab catches everything heavier
RATES = {
    "IN": [(1, 40), (5, 90), (10, 160), (float("inf"), 250)],
    "US": [(1, 800), (5, 1500), (float("inf"), 2500)],
    "UK": [(1, 700), (5, 1300), (float("inf"), 2200)],
}


def _base_charge(country, weight):
    for max_weight, charge in RATES[country]:
        if weight <= max_weight:
            return charge


def shipping_charge_after(country, weight, express, insured, member):
    if country not in RATES:
        return -1
    charge = _base_charge(country, weight)
    charge = charge * 2 if express else charge
    charge = charge + 50 if insured else charge
    charge = charge * 0.9 if member else charge
    return round(charge, 2)
