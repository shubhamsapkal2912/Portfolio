# Software Testing - Slip Solutions

Each slip folder has `q1/` and `q2/` (Q.3 is viva - oral). Style follows Ass1-Ass10 of the lab book.

| Slip | Q1 | Q2 |
|---|---|---|
| s1 | even_odd.py | login_test_data.xlsx |
| s2 | feedback_form.html, feedback_form_defects.xlsx | rtm_with_test_data.xlsx |
| s3 | job_application.html, job_application_defect_report.xlsx | boundary_testing.xlsx |
| s4 | login_redesign.html, ux_feedback_session.xlsx, ux_findings_summary.md | contact_form.py, contact_form_test_cases.xlsx |
| s5 | grade_calc.py | bank.py, banking_test_cases.xlsx |
| s6 | digit_sum.py | bank.py, risk_based_prioritization.xlsx |
| s7 | coverage_report.md, coverage_report.txt, shipping.py | decision_table_discount.xlsx, discount.py |
| s8 | coverage_before_after.md, inventory.py | atm_withdrawal_decision_table.xlsx |
| s9 | cc_comparison.md, ticket_v1.py, ticket_v2.py | course_access_decision_table.xlsx |
| s10 | refactor_report.md, shipping_after.py, shipping_before.py | age_equivalence_classes.xlsx |
| s11 | rtm_login_module.xlsx | email_phone_equivalence_classes.xlsx |
| s12 | palindrome.py | signup_combinations.xlsx |
| s13 | rtm_hotel_system.xlsx | rtm_food_ordering_system.xlsx, usecase_food_ordering.xlsx |
| s14 | prime_check.py | signup_test_fields.xlsx |
| s15 | enquiry_form.html, enquiry_form_defects.xlsx | usecase_bus_ticket_booking.xlsx |
| s16 | coverage_report.md, coverage_report.txt, password_check.py | signup_test_fields.xlsx |
| s17 | rtm_login_module.xlsx | email_phone_equivalence_classes.xlsx |
| s18 | bank_account.py, coverage_before_after.md | email_phone_equivalence_classes.xlsx |
| s19 | internship_application.html, internship_application_defect_report.xlsx | boundary_testing.xlsx |
| s20 | coverage_before_after.md, library_fine.py | boundary_testing.xlsx |
| s21 | rtm_login_module.xlsx | original_login_page.html, ux_issues_and_improvements.xlsx |
| s22 | coverage_before_after.md, temperature.py | cfg_sum_positive.png, manual_coverage.md, sample.py |
| s23 | rtm_library_system.xlsx | decision_table_discount.xlsx, discount.py |
| s24 | leap_year.py | leave_form.html, leave_form_defects.xlsx |
| s25 | scholarship_application.html, scholarship_application_defect_report.xlsx | boundary_testing.xlsx |
| s26 | login_redesign.html, ux_feedback_session.xlsx, ux_findings_summary.md | contact_form.py, contact_form_test_cases.xlsx |
