from contact_form import validate_contact

def test_tc01():
    assert validate_contact(name='Priya Deshmukh', email='priya@gmail.com', message='Quote needed', phone='9876543210') == 'Form submitted successfully'

def test_tc02():
    assert validate_contact(name='Amit Shah', email='amit@abc.com', message='Hello team', phone='') == 'Form submitted successfully'

def test_tc03():
    assert validate_contact(name='Neha', email='neha@xyz.com', message='m' * 500, phone='9123456780') == 'Form submitted successfully'

def test_tc04():
    assert validate_contact(name='Ronit123', email='ronit@gmail.com', message='Hello', phone='9876543210') == 'Invalid name'

def test_tc05():
    assert validate_contact(name='Ronit', email='ronit@gmail.com', message='Hello', phone='987654321') == 'Invalid phone'

def test_tc06():
    assert validate_contact(name='Ronit', email='ronit@gmail.com', message='m' * 501, phone='9876543210') == 'Message too long'
