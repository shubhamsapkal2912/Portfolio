import re


def validate_contact(name, email, message, phone=""):
    """Returns the message the contact form displays."""
    errors = []
    if not name.strip():
        errors.append("Name is required")
    elif not re.fullmatch(r"[A-Za-z ]{2,50}", name.strip()):
        errors.append("Invalid name")
    if not email.strip():
        errors.append("Email is required")
    elif not re.fullmatch(r"[\w.+-]+@[\w-]+(\.[\w-]+)*\.[A-Za-z]{2,}", email.strip()):
        errors.append("Invalid email")
    if not message.strip():
        errors.append("Message is required")
    elif len(message) > 500:
        errors.append("Message too long")
    if phone and not re.fullmatch(r"[6-9]\d{9}", phone):
        errors.append("Invalid phone")
    return "Form submitted successfully" if not errors else "; ".join(errors)
