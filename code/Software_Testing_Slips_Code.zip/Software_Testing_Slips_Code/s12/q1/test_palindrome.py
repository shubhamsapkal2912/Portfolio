from palindrome import reverse_number, is_palindrome

def test_reverse():
    assert reverse_number(1234) == 4321

def test_palindrome_true():
    assert is_palindrome(121)

def test_palindrome_false():
    assert not is_palindrome(123)

def test_zero():
    assert reverse_number(0) == 0
