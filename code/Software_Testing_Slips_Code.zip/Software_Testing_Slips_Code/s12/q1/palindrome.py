def reverse_number(n):
    rev = 0
    while n > 0:
        rev = rev * 10 + n % 10
        n //= 10
    return rev


def is_palindrome(n):
    return n == reverse_number(n)


if __name__ == "__main__":
    for num in (121, 123, 4554, 10):
        print(num, "reversed =", reverse_number(num),
              "-> palindrome" if is_palindrome(num) else "-> not palindrome")
