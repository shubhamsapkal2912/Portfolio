def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True


def primes_upto(limit):
    result = []
    for n in range(2, limit + 1):
        if is_prime(n):
            result.append(n)
    return result


if __name__ == "__main__":
    print("Primes up to 30:", primes_upto(30))
    for n in (1, 2, 15, 17):
        print(n, "is prime" if is_prime(n) else "is not prime")
