from prime_check import is_prime, primes_upto

def test_prime_numbers():
    assert is_prime(2) and is_prime(17)

def test_not_prime():
    assert not is_prime(1) and not is_prime(15)

def test_range():
    assert primes_upto(10) == [2, 3, 5, 7]
