from grade_calc import get_grade, grade_report

def test_distinction():
    assert get_grade(75) == "Distinction"

def test_first_class():
    assert get_grade(60) == "First Class"

def test_pass():
    assert get_grade(40) == "Pass"

def test_fail():
    assert get_grade(39) == "Fail"

def test_report():
    assert grade_report({"A": 80, "B": 10}) == {"A": "Distinction", "B": "Fail"}
