def get_grade(marks):
    if marks >= 75:
        return "Distinction"
    elif marks >= 60:
        return "First Class"
    elif marks >= 40:
        return "Pass"
    else:
        return "Fail"


def grade_report(students):
    report = {}
    for name, marks in students.items():
        report[name] = get_grade(marks)
    return report


if __name__ == "__main__":
    data = {"Amit": 82, "Sneha": 66, "Rahul": 45, "Priya": 30}
    for student, grade in grade_report(data).items():
        print(f"{student:<8} -> {grade}")
