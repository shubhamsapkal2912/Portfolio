class Bank:
    DEPOSIT_LIMIT = 50000
    WITHDRAW_LIMIT = 20000

    def __init__(self):
        self.accounts = {"1234567890": 10000, "9876543210": 500}

    def _check_account(self, acc):
        if acc not in self.accounts:
            raise ValueError("Invalid account")

    def deposit(self, acc, amount):
        self._check_account(acc)
        if amount <= 0:
            raise ValueError("Invalid amount")
        if amount > self.DEPOSIT_LIMIT:
            raise ValueError("Deposit limit exceeded")
        self.accounts[acc] += amount
        return self.accounts[acc]

    def withdraw(self, acc, amount):
        self._check_account(acc)
        if amount <= 0:
            raise ValueError("Invalid amount")
        if amount > self.WITHDRAW_LIMIT:
            raise ValueError("Withdrawal limit exceeded")
        if amount > self.accounts[acc]:
            raise ValueError("Insufficient balance")
        self.accounts[acc] -= amount
        return self.accounts[acc]

    def transfer(self, src, dst, amount):
        self._check_account(src)
        self._check_account(dst)
        self.withdraw(src, amount)
        self.deposit(dst, amount)
        return True
