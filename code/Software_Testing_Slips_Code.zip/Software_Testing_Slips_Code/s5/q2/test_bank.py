import pytest
from bank import Bank


def run(fn, *a):
    try:
        return 'OK:' + str(getattr(Bank(), fn)(*a))
    except ValueError as e:
        return 'ERR:' + str(e)

def test_bk01():
    assert run('deposit', *('1234567890', 5000)) == 'OK:15000'

def test_bk02():
    assert run('deposit', *('1234567890', 50000)) == 'OK:60000'

def test_bk03():
    assert run('withdraw', *('1234567890', 2000)) == 'OK:8000'

def test_bk04():
    assert run('withdraw', *('9876543210', 500)) == 'OK:0'

def test_bk05():
    assert run('transfer', *('1234567890', '9876543210', 1000)) == 'OK:True'

def test_bk06():
    assert run('deposit', *('0000000000', 1000)) == 'ERR:Invalid account'

def test_bk07():
    assert run('deposit', *('1234567890', -500)) == 'ERR:Invalid amount'

def test_bk08():
    assert run('deposit', *('1234567890', 0)) == 'ERR:Invalid amount'

def test_bk09():
    assert run('deposit', *('1234567890', 50001)) == 'ERR:Deposit limit exceeded'

def test_bk10():
    assert run('withdraw', *('9876543210', 1000)) == 'ERR:Insufficient balance'

def test_bk11():
    assert run('withdraw', *('1234567890', -100)) == 'ERR:Invalid amount'

def test_bk12():
    assert run('withdraw', *('1234567890', 25000)) == 'ERR:Withdrawal limit exceeded'

def test_bk13():
    assert run('transfer', *('1234567890', '1111111111', 500)) == 'ERR:Invalid account'
