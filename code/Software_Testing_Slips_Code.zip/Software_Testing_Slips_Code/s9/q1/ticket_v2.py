WEEKDAY_WEEKEND = {            # (weekday, weekend) price tables
    "child":   (60, 80),
    "student": (100, 120),
    "adult":   (150, 200),
    "senior":  (80, 100),
}


def _category(age, is_student):
    if age < 12:
        return "child"
    if age >= 60:
        return "senior"
    return "student" if is_student else "adult"


def ticket_price_v2(age, is_student, is_weekend, has_coupon):
    """Version 2 - same behaviour, logic moved into a lookup table."""
    if age < 5:
        return 0
    weekday, weekend = WEEKDAY_WEEKEND[_category(age, is_student)]
    price = weekend if is_weekend else weekday
    return price - 20 if has_coupon else price
