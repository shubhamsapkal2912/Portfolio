def ticket_price_v1(age, is_student, is_weekend, has_coupon):
    """Version 1 - nested if / elif ladder (high complexity)."""
    price = 0
    if age < 5:
        price = 0
    elif age < 12:
        if is_weekend:
            price = 80
        else:
            price = 60
    elif age < 60:
        if is_student:
            if is_weekend:
                price = 120
            else:
                price = 100
        else:
            if is_weekend:
                price = 200
            else:
                price = 150
    else:
        if is_weekend:
            price = 100
        else:
            price = 80
    if has_coupon:
        if price > 0:
            price = price - 20
    return price
