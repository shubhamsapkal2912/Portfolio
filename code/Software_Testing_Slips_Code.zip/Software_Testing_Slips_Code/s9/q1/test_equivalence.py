import itertools
from ticket_v1 import ticket_price_v1
from ticket_v2 import ticket_price_v2


def test_both_versions_give_same_result():
    for age, stu, wk, cp in itertools.product([0, 4, 5, 11, 12, 30, 59, 60, 80],
                                              [True, False], [True, False], [True, False]):
        assert ticket_price_v1(age, stu, wk, cp) == ticket_price_v2(age, stu, wk, cp)
