# Compare Two Versions - Cyclomatic Complexity  (Slip 9 Q1)

Both versions compute the same ticket price (verified by `test_equivalence.py`, result below).

## Manual calculation  V(G) = D + 1   (D = decision points)

### Version 1 (`ticket_v1.py`) - nested ladder
Decision points: `age<5`, `age<12`, `is_weekend`(child), `age<60`, `is_student`, `is_weekend`(student),
`is_weekend`(adult), `is_weekend`(senior), `has_coupon`, `price>0`  ->  **D = 10**  ->  **V(G) = 11**

### Version 2 (`ticket_v2.py`) - table driven
* `ticket_price_v2`: `age<5`, `is_weekend` (ternary), `has_coupon` (ternary) -> D=3 -> V(G)=4
* `_category`: `age<12`, `age>=60`, `is_student` (ternary) -> D=3 -> V(G)=4

## Tool result (radon)
```
ticket_v1.py
    F 1:0 ticket_price_v1 - C (11)
ticket_v2.py
    F 9:0 _category - A (4)
    F 17:0 ticket_price_v2 - A (4)
```
(radon counts: v1 = 11; v2 = 4 + 4 per function, highest = 4)

| | Version 1 | Version 2 |
|---|---|---|
| Functions | 1 | 2 |
| V(G) per function | **11** (moderate) | **4** and **4** (simple) |
| Min. test cases for branch coverage | 11 | 4 + 4 spread over two small units |
| Rating (1-10 simple, 11-20 moderate) | Moderate | Simple |

## Comments on complexities
* V1 has one function with 11 independent paths; every price change forces the reader to
  walk a 4-level nested tree. V2 splits the problem into a data table and a tiny classifier, each with V(G)=4.
* V2 gives identical output but the **maximum** complexity of any single unit dropped from 11 to 4.

## How reducing CC improves maintainability
1. **Readability** - fewer nested branches, easier to understand quickly.
2. **Fewer test cases per unit** - each small function needs only V(G) tests.
3. **Fewer defects** - defect density rises with complexity; less branching = fewer places to go wrong.
4. **Easier change** - a new price is a one-line table edit, not a change to nested logic (lower regression risk).
5. **Easier debugging / review** - small single-purpose functions.

## Equivalence test result
```
.                                                                        [100%]
1 passed in 0.01s
```
