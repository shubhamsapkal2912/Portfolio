# UX Findings Summary - Redesigned Login Page (Slip 4 Q1)

Page: `login_redesign.html` (open in a browser; demo login `Ronit` / `Ronit@123`).

## What changed (old Ass2 login page -> redesign)
* **UX-1** Password was visible (type=text) -> type=password + Show/Hide toggle
* **UX-2** Forgot Password below the Login button -> Link moved to the row directly under the password field
* **UX-3** Generic alert 'Login Failed.' -> Inline field-level messages + status line (no pop-up)
* **UX-4** No labels linked to inputs, no autofocus -> label for/id, autofocus, aria-describedby, role=alert
* **UX-5** Fixed 350px width, not mobile friendly -> Responsive card (max-width 380px, 100% on small screens)

## Feedback session (3 participants)
Task given: *log in with wrong data, read the error, then log in correctly; try to find Forgot Password.*

| Measure | Result |
|---|---|
| Task completion | 3 / 3 |
| Average time to log in | 4.3 s |
| Ease of use (avg of 5) | 4.3 |
| Satisfaction (avg of 5) | 4.7 |

### Key findings
* All users understood the inline error messages immediately (no pop-up confusion).
* Show/Hide password was appreciated; one user needed an icon instead of text.
* 'Forgot password' placement under the password field was found quickly by all.
* Suggestions: larger touch target on mobile, eye icon, optional OTP login.

> NOTE: participant data in `ux_feedback_session.xlsx` is sample data to show the format.
> Run the session with 3 real people and overwrite the table before submitting.
