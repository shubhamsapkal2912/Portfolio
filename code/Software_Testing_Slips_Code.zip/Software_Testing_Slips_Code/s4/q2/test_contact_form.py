from contact_form import validate_contact

def test_tc01():
    assert validate_contact(name='Ronit Khupase', email='ronit@gmail.com', message='Need more information') == 'Form submitted successfully'

def test_tc02():
    assert validate_contact(name='Al', email='al@x.com', message='Hi') == 'Form submitted successfully'

def test_tc03():
    assert validate_contact(name='Sneha Patil', email='sneha.p+test@mail.co.in', message='Please call') == 'Form submitted successfully'

def test_tc04():
    assert validate_contact(name='', email='ronit@gmail.com', message='Hello') == 'Name is required'

def test_tc05():
    assert validate_contact(name='Ronit', email='ronitgmail.com', message='Hello') == 'Invalid email'

def test_tc06():
    assert validate_contact(name='Ronit', email='ronit@gmail.com', message='') == 'Message is required'
