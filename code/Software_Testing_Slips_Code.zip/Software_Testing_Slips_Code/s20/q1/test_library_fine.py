from library_fine import calculate_fine, can_borrow, renewal_days

def test_no_fine():
    assert calculate_fine(0, "student") == 0

def test_student_fine():
    assert calculate_fine(10, "student") == 10

def test_staff_fine():
    assert calculate_fine(10, "staff") == 20

def test_guest_fine_and_cap():
    assert calculate_fine(10, "guest") == 50
    assert calculate_fine(1000, "guest") == 500

def test_can_borrow():
    assert can_borrow(2, False) is True
    assert can_borrow(2, True) is False
    assert can_borrow(5, False) is False

def test_renewal_days():
    assert renewal_days("student") == 7
    assert renewal_days("staff") == 14
    assert renewal_days("guest") == 3
