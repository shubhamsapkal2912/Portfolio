def calculate_fine(days_late, member_type):
    if days_late <= 0:
        return 0
    if member_type == "student":
        rate = 1
    elif member_type == "staff":
        rate = 2
    else:
        rate = 5
    fine = days_late * rate
    if fine > 500:
        fine = 500
    return fine


def can_borrow(books_issued, has_pending_fine):
    if has_pending_fine:
        return False
    if books_issued >= 5:
        return False
    return True


def renewal_days(member_type):
    if member_type == "student":
        return 7
    elif member_type == "staff":
        return 14
    return 3
