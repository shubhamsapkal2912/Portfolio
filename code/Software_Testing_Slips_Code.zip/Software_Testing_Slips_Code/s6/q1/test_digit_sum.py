from digit_sum import digit_sum

def test_zero():
    assert digit_sum(0) == 0          # while loop runs 0 times

def test_single():
    assert digit_sum(7) == 7          # loop runs once

def test_multi():
    assert digit_sum(123) == 6        # loop runs many times

def test_negative():
    assert digit_sum(-45) == 9
