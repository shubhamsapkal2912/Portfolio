def digit_sum(n):
    n = abs(n)
    total = 0
    while n > 0:
        total += n % 10      # take last digit
        n //= 10             # drop last digit
    return total


if __name__ == "__main__":
    for num in (0, 7, 123, 98765):
        print(f"Sum of digits of {num} = {digit_sum(num)}")
