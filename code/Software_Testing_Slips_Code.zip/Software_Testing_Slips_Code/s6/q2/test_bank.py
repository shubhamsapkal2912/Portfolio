from bank import Bank


def run(fn, *a):
    try:
        return 'OK:' + str(getattr(Bank(), fn)(*a))
    except ValueError as e:
        return 'ERR:' + str(e)

def test_tc01():
    assert run('withdraw', *('9876543210', 1000)) == 'ERR:Insufficient balance'

def test_tc02():
    assert run('transfer', *('1234567890', '1111111111', 500)) == 'ERR:Invalid account'

def test_tc03():
    assert run('withdraw', *('1234567890', 25000)) == 'ERR:Withdrawal limit exceeded'

def test_tc04():
    assert run('withdraw', *('1234567890', 2000)) == 'OK:8000'

def test_tc05():
    assert run('transfer', *('1234567890', '9876543210', 1000)) == 'OK:True'

def test_tc06():
    assert run('deposit', *('1234567890', -500)) == 'ERR:Invalid amount'

def test_tc07():
    assert run('deposit', *('1234567890', 50001)) == 'ERR:Deposit limit exceeded'

def test_tc08():
    assert run('deposit', *('1234567890', 5000)) == 'OK:15000'

def test_tc09():
    assert run('deposit', *('0000000000', 100)) == 'ERR:Invalid account'

def test_tc10():
    assert run('deposit', *('1234567890', 0)) == 'ERR:Invalid amount'
