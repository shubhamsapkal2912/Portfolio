import pytest
from inventory import Inventory

def test_add_item():
    inv = Inventory()
    inv.add_item("pen", 10)
    assert inv.stock["pen"] == 10

def test_add_invalid_qty():
    with pytest.raises(ValueError):
        Inventory().add_item("pen", 0)

def test_remove_item():
    inv = Inventory()
    inv.add_item("pen", 10)
    inv.remove_item("pen", 4)
    assert inv.stock["pen"] == 6

def test_remove_all_deletes_item():
    inv = Inventory()
    inv.add_item("pen", 3)
    inv.remove_item("pen", 3)
    assert "pen" not in inv.stock

def test_remove_missing_item():
    with pytest.raises(KeyError):
        Inventory().remove_item("ghost", 1)

def test_remove_too_much():
    inv = Inventory()
    inv.add_item("pen", 2)
    with pytest.raises(ValueError):
        inv.remove_item("pen", 5)

def test_low_stock_and_total():
    inv = Inventory()
    inv.add_item("pen", 2)
    inv.add_item("book", 20)
    assert inv.low_stock() == ["pen"]
    assert inv.total_items() == 22
