class Inventory:
    def __init__(self):
        self.stock = {}

    def add_item(self, name, qty):
        if qty <= 0:
            raise ValueError("Quantity must be positive")
        self.stock[name] = self.stock.get(name, 0) + qty

    def remove_item(self, name, qty):
        if name not in self.stock:
            raise KeyError("Item not found")
        if qty > self.stock[name]:
            raise ValueError("Insufficient stock")
        self.stock[name] -= qty
        if self.stock[name] == 0:
            del self.stock[name]

    def low_stock(self, threshold=5):
        return [n for n, q in self.stock.items() if q < threshold]

    def total_items(self):
        return sum(self.stock.values())
