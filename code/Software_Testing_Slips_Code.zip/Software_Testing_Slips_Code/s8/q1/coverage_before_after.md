# Improve Test Coverage to 50%+  - `inventory.py`  (Slip 8 Q1)

## Method
1. Write the minimal test(s) and measure: `coverage run --branch -m pytest` then `coverage report -m`.
2. Read the **Missing** column - these lines/branches were never executed.
3. Add a test per missed branch (invalid input, error path, each `elif`/`else`).
4. Re-measure and compare.

## Source under test
```python
class Inventory:
    def __init__(self):
        self.stock = {}

    def add_item(self, name, qty):
        if qty <= 0:
            raise ValueError("Quantity must be positive")
        self.stock[name] = self.stock.get(name, 0) + qty

    def remove_item(self, name, qty):
        if name not in self.stock:
            raise KeyError("Item not found")
        if qty > self.stock[name]:
            raise ValueError("Insufficient stock")
        self.stock[name] -= qty
        if self.stock[name] == 0:
            del self.stock[name]

    def low_stock(self, threshold=5):
        return [n for n, q in self.stock.items() if q < threshold]

    def total_items(self):
        return sum(self.stock.values())
```

## BEFORE - tests
```python
from inventory import Inventory

def test_add_item():
    inv = Inventory()
    inv.add_item("pen", 10)
    assert inv.stock["pen"] == 10
```
```
Name           Stmts   Miss Branch BrPart  Cover   Missing
----------------------------------------------------------
inventory.py      19     10      8      1    37%   7, 11-17, 20, 23
----------------------------------------------------------
TOTAL             19     10      8      1    37%
```
Coverage before = **37%** (missed lines [7, 11, 12, 13, 14, 15, 16, 17, 20, 23])

## AFTER - tests
```python
import pytest
from inventory import Inventory

def test_add_item():
    inv = Inventory()
    inv.add_item("pen", 10)
    assert inv.stock["pen"] == 10

def test_add_invalid_qty():
    with pytest.raises(ValueError):
        Inventory().add_item("pen", 0)

def test_remove_item():
    inv = Inventory()
    inv.add_item("pen", 10)
    inv.remove_item("pen", 4)
    assert inv.stock["pen"] == 6

def test_remove_all_deletes_item():
    inv = Inventory()
    inv.add_item("pen", 3)
    inv.remove_item("pen", 3)
    assert "pen" not in inv.stock

def test_remove_missing_item():
    with pytest.raises(KeyError):
        Inventory().remove_item("ghost", 1)

def test_remove_too_much():
    inv = Inventory()
    inv.add_item("pen", 2)
    with pytest.raises(ValueError):
        inv.remove_item("pen", 5)

def test_low_stock_and_total():
    inv = Inventory()
    inv.add_item("pen", 2)
    inv.add_item("book", 20)
    assert inv.low_stock() == ["pen"]
    assert inv.total_items() == 22
```
```
Name           Stmts   Miss Branch BrPart  Cover   Missing
----------------------------------------------------------
inventory.py      19      0      8      0   100%
----------------------------------------------------------
TOTAL             19      0      8      0   100%
```
Coverage after = **100%** (missed lines [])

## Comparison
| Metric | Before | After |
|---|---|---|
| Statements | 19 | 19 |
| Statements missed | 10 | 0 |
| Branches covered | 1/8 | 8/8 |
| **Total coverage** | **37%** | **100%** |
| Target | | 50%+  ->  **achieved** |

## Improvements documented
* Number of test functions increased and every public function is now called.
* Negative / error paths (`raise`, invalid input) now exercised.
* Each `if / elif / else` branch has at least one test.

pytest result after improvement:
```
.......                                                                  [100%]
7 passed in 0.03s
```
