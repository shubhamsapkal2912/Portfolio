class BankAccount:
    def __init__(self, owner, balance=0):
        self.owner = owner
        self.balance = balance

    def deposit(self, amount):
        if amount <= 0:
            raise ValueError("Deposit must be positive")
        self.balance += amount
        return self.balance

    def withdraw(self, amount):
        if amount <= 0:
            raise ValueError("Withdrawal must be positive")
        if amount > self.balance:
            raise ValueError("Insufficient funds")
        self.balance -= amount
        return self.balance

    def interest(self, rate):
        if rate < 0:
            return 0
        return self.balance * rate / 100

    def account_type(self):
        if self.balance >= 100000:
            return "Gold"
        elif self.balance >= 10000:
            return "Silver"
        return "Basic"
