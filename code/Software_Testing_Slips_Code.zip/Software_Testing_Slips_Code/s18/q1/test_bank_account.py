import pytest
from bank_account import BankAccount

def test_deposit():
    acc = BankAccount("Ronit", 100)
    assert acc.deposit(50) == 150

def test_deposit_invalid():
    with pytest.raises(ValueError):
        BankAccount("Ronit").deposit(-5)

def test_withdraw():
    assert BankAccount("Ronit", 500).withdraw(200) == 300

def test_withdraw_invalid_amount():
    with pytest.raises(ValueError):
        BankAccount("Ronit", 500).withdraw(0)

def test_withdraw_insufficient():
    with pytest.raises(ValueError):
        BankAccount("Ronit", 100).withdraw(500)

def test_interest():
    assert BankAccount("Ronit", 1000).interest(5) == 50
    assert BankAccount("Ronit", 1000).interest(-1) == 0

def test_account_types():
    assert BankAccount("a", 150000).account_type() == "Gold"
    assert BankAccount("a", 20000).account_type() == "Silver"
    assert BankAccount("a", 10).account_type() == "Basic"
