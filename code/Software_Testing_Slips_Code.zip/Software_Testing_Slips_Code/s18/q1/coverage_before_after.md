# Improve Test Coverage to 60%+  - `bank_account.py`  (Slip 18 Q1)

## Method
1. Write the minimal test(s) and measure: `coverage run --branch -m pytest` then `coverage report -m`.
2. Read the **Missing** column - these lines/branches were never executed.
3. Add a test per missed branch (invalid input, error path, each `elif`/`else`).
4. Re-measure and compare.

## Source under test
```python
class BankAccount:
    def __init__(self, owner, balance=0):
        self.owner = owner
        self.balance = balance

    def deposit(self, amount):
        if amount <= 0:
            raise ValueError("Deposit must be positive")
        self.balance += amount
        return self.balance

    def withdraw(self, amount):
        if amount <= 0:
            raise ValueError("Withdrawal must be positive")
        if amount > self.balance:
            raise ValueError("Insufficient funds")
        self.balance -= amount
        return self.balance

    def interest(self, rate):
        if rate < 0:
            return 0
        return self.balance * rate / 100

    def account_type(self):
        if self.balance >= 100000:
            return "Gold"
        elif self.balance >= 10000:
            return "Silver"
        return "Basic"
```

## BEFORE - tests
```python
from bank_account import BankAccount

def test_deposit():
    acc = BankAccount("Ronit", 100)
    assert acc.deposit(50) == 150
```
```
Name              Stmts   Miss Branch BrPart  Cover   Missing
-------------------------------------------------------------
bank_account.py      26     15     12      1    32%   8, 13-18, 21-23, 26-30
-------------------------------------------------------------
TOTAL                26     15     12      1    32%
```
Coverage before = **32%** (missed lines [8, 13, 14, 15, 16, 17, 18, 21, 22, 23, 26, 27, 28, 29, 30])

## AFTER - tests
```python
import pytest
from bank_account import BankAccount

def test_deposit():
    acc = BankAccount("Ronit", 100)
    assert acc.deposit(50) == 150

def test_deposit_invalid():
    with pytest.raises(ValueError):
        BankAccount("Ronit").deposit(-5)

def test_withdraw():
    assert BankAccount("Ronit", 500).withdraw(200) == 300

def test_withdraw_invalid_amount():
    with pytest.raises(ValueError):
        BankAccount("Ronit", 500).withdraw(0)

def test_withdraw_insufficient():
    with pytest.raises(ValueError):
        BankAccount("Ronit", 100).withdraw(500)

def test_interest():
    assert BankAccount("Ronit", 1000).interest(5) == 50
    assert BankAccount("Ronit", 1000).interest(-1) == 0

def test_account_types():
    assert BankAccount("a", 150000).account_type() == "Gold"
    assert BankAccount("a", 20000).account_type() == "Silver"
    assert BankAccount("a", 10).account_type() == "Basic"
```
```
Name              Stmts   Miss Branch BrPart  Cover   Missing
-------------------------------------------------------------
bank_account.py      26      0     12      0   100%
-------------------------------------------------------------
TOTAL                26      0     12      0   100%
```
Coverage after = **100%** (missed lines [])

## Comparison
| Metric | Before | After |
|---|---|---|
| Statements | 26 | 26 |
| Statements missed | 15 | 0 |
| Branches covered | 1/12 | 12/12 |
| **Total coverage** | **32%** | **100%** |
| Target | | 60%+  ->  **achieved** |

## Improvements documented
* Number of test functions increased and every public function is now called.
* Negative / error paths (`raise`, invalid input) now exercised.
* Each `if / elif / else` branch has at least one test.

pytest result after improvement:
```
.......                                                                  [100%]
7 passed in 0.03s
```
