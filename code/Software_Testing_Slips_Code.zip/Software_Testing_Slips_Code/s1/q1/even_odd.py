def classify_numbers(limit):
    """Loop 1..limit, classify each number as even/odd, return both sums."""
    even_sum = 0
    odd_sum = 0
    for n in range(1, limit + 1):
        if n % 2 == 0:
            print(f"{n} is even")
            even_sum += n
        else:
            print(f"{n} is odd")
            odd_sum += n
    return even_sum, odd_sum


if __name__ == "__main__":
    e, o = classify_numbers(10)
    print("Sum of even numbers:", e)
    print("Sum of odd numbers :", o)
