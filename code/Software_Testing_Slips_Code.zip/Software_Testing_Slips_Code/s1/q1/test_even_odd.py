from even_odd import classify_numbers

def test_limit_10():
    assert classify_numbers(10) == (30, 25)

def test_limit_zero():
    assert classify_numbers(0) == (0, 0)

def test_limit_one():
    assert classify_numbers(1) == (0, 1)
