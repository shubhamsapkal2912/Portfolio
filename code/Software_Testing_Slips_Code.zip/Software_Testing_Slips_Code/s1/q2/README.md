Positive = valid username + valid password -> login succeeds.
Negative = invalid / empty / wrong data -> login rejected with message.
Rules assumed: username 3+ alphanumeric; password 8+ chars with upper, lower, digit and special character.
