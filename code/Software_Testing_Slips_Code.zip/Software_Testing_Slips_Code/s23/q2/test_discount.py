from discount import discount_percent, final_amount

def test_tc01():
    assert discount_percent(True, 1500) == 15
    assert final_amount(True, 1500) == 1275.0

def test_tc02():
    assert discount_percent(True, 800) == 10
    assert final_amount(True, 800) == 720.0

def test_tc03():
    assert discount_percent(False, 1500) == 5
    assert final_amount(False, 1500) == 1425.0

def test_tc04():
    assert discount_percent(False, 800) == 0
    assert final_amount(False, 800) == 800.0

def test_tc05():
    assert discount_percent(True, 1000) == 10
    assert final_amount(True, 1000) == 900.0

def test_tc06():
    assert discount_percent(False, 1001) == 5
    assert final_amount(False, 1001) == 950.95
