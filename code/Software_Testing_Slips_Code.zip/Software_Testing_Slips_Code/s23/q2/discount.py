def discount_percent(is_member, order_amount):
    if is_member:
        return 15 if order_amount > 1000 else 10
    return 5 if order_amount > 1000 else 0


def final_amount(is_member, order_amount):
    return order_amount * (100 - discount_percent(is_member, order_amount)) / 100
